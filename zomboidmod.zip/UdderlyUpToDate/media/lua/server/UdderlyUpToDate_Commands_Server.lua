local modName = "UdderlyUpToDate"
--Udderly Commands
print("["..modName.."] Initializing UdderlyCommands Server..")
UdderlyUpToDate = UdderlyUpToDate or {}
UdderlyUpToDate.CommandHandlers = {}

Events.OnClientCommand.Add(function(moduleName, command, player, args)
	--print("["..modName.."] OnClientCommand \""..moduleName.."\", \""..command.."\"..")
	if moduleName == modName then
		local commandHandler = UdderlyUpToDate.CommandHandlers[command]
		if commandHandler then
			print("["..modName.."] Running command \""..command.."\" for player \""..player:getUsername().."\".")
			commandHandler(player, args)
		else
			print("["..modName.."] Unknown command \""..command.."\" from player \""..player:getUsername().."\"!")
		end
	end
end)

print("["..modName.."] Initializing UdderlyCommands Command Handlers..")
UdderlyUpToDate.CommandHandlers["checkworkshop"] = function(player, args)
	UdderlyUpToDate.pollWorkshop()
end

UdderlyUpToDate.CommandHandlers["restart"] = function(player, args)
	local restartSeconds = (SandboxVars.UdderlyUpToDate.RestartDelayMinutes or 15) * 60;
	UdderlyUpToDate.startRestartCountdown(getTimestamp() + restartSeconds) 
end

UdderlyUpToDate.CommandHandlers["restartnow"] = function(player, args)
	UdderlyUpToDate.scheduleServerRestart(1) --Scheduled for the first tick of the game so it just happens right now.
end

UdderlyUpToDate.CommandHandlers["schedulerestart"] = function(player, args)
	UdderlyUpToDate.scheduleServerRestart(getTimestamp() + (args[1] * 60))
end